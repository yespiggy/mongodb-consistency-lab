# Measured results

Cells show violations / eligible checks; a dash means no eligible check. Timeouts are not violations.

| Scenario | Config | Histories | RYW | MR | MW | WFR | Operation errors |
|---|---|---:|---:|---:|---:|---:|---:|
| normal | A | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | E | 20 | 20/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | G | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | D | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | B | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | H | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | C | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| normal | F | 20 | 0/20 | 0/20 | 0/20 | 0/20 | 0/80 |
| replication_lag | A | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | G | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | B | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | D | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | F | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | C | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | H | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| replication_lag | E | 10 | 10/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | G | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | D | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | F | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | C | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | H | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | B | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | E | 10 | 10/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| secondary_crash | A | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | A | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | E | 10 | 10/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | C | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | D | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | F | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | G | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | H | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| primary_crash | B | 10 | 0/10 | 0/10 | 0/10 | 0/10 | 0/40 |
| network_partition_2_1 | C | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/50 |
| network_partition_2_1 | B | 10 | 0/10 | - | 0/10 | 0/10 | 20/50 |
| network_partition_2_1 | E | 10 | 10/10 | 0/10 | 0/10 | 0/10 | 10/50 |
| network_partition_2_1 | A | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/50 |
| network_partition_2_1 | D | 10 | 0/10 | - | 0/10 | 0/10 | 20/50 |
| network_partition_2_1 | G | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/50 |
| network_partition_2_1 | F | 10 | 0/10 | - | 0/10 | 0/10 | 20/50 |
| network_partition_2_1 | H | 10 | 0/10 | - | 0/10 | 0/10 | 20/50 |
| network_partition | H | 10 | - | - | - | - | 50/50 |
| network_partition | D | 10 | - | - | - | - | 40/50 |
| network_partition | E | 10 | 10/10 | 0/10 | 0/10 | 0/10 | 10/50 |
| network_partition | F | 10 | - | - | 0/10 | - | 30/50 |
| network_partition | A | 10 | 10/10 | 10/10 | 0/10 | 0/10 | 10/50 |
| network_partition | C | 10 | - | 10/10 | - | - | 30/50 |
| network_partition | B | 10 | 0/10 | - | 0/10 | 0/10 | 20/50 |
| network_partition | G | 10 | - | 0/10 | - | - | 30/50 |
| partition_rollback | E | 10 | 9/9 | 0/8 | 8/8 | 0/8 | 4/40 |
| partition_rollback | G | 10 | - | 0/10 | - | 0/6 | 14/40 |
| partition_rollback | F | 10 | 7/7 | - | 9/9 | - | 14/40 |
| partition_rollback | C | 10 | - | 9/9 | - | 7/7 | 14/40 |
| partition_rollback | A | 10 | 10/10 | 10/10 | 10/10 | 10/10 | 0/40 |
| partition_rollback | B | 10 | 6/7 | 6/6 | 6/6 | 6/6 | 8/40 |
| partition_rollback | D | 10 | - | 9/9 | - | 3/3 | 18/40 |
| partition_rollback | H | 10 | - | - | - | - | 34/40 |
